#include "GameFever.h"

GameFever::GameFever()
{
	miFever = FEVER_INIT_VAL;
}

GameFever::~GameFever()
{
}

void GameFever::printFever()
{
	// FEVER茵・ず
	PrintFever();

	// FEVER茵・ず
	PrintFeverF();
	PrintFeverE();
	PrintFeverV();
	PrintFeverE2();
	PrintFeverR();
}

