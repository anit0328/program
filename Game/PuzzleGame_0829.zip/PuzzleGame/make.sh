g++ main.cpp \
	GameWindow.cpp \
	GameManager.cpp \
	GameDisplay.cpp \
	GamePuzzleManager.cpp \
	GamePuzzle.cpp \
 -o exe/PuzzleGame
