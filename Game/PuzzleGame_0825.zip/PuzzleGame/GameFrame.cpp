#include "GameFrame.h"

void GameFrame::printFrame()
{
	PrintFrameTop();
	PrintFrameSides();
	PrintFrameBottom();
}
