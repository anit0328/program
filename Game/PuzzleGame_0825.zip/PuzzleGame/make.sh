g++ main.cpp \
	GameWindow.cpp \
	GameManager.cpp \
	GameFrame.cpp \
	GameScore.cpp \
	GameFever.cpp \
	GameTimeGauge.cpp \
	GamePuzzleManager.cpp \
	GamePuzzle.cpp \
 -o exe/PuzzleGame
